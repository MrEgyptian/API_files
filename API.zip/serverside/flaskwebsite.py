import os
from flask import Flask, redirect, url_for
from flask_dance.contrib.facebook import make_facebook_blueprint, facebook

app = Flask(__name__)
app.secret_key = 'haha'
app.config["FACEBOOK_OAUTH_CLIENT_ID"] = "1640259209747641"
app.config["FACEBOOK_OAUTH_CLIENT_SECRET"] = "2a6a22042cb145610341e9851c20145b"
facebook_bp = make_facebook_blueprint()
app.register_blueprint(facebook_bp, url_prefix="/auto_respond_login")

@app.route("/auto_respond_login")
def index():
    if not facebook.authorized:
        return redirect(url_for("facebook.login"))
    resp = facebook.get("/me")
    assert resp.ok, resp.text
    return f"You are {resp.json()['name']} on Facebook and your token is \"{facebook.access_token}\""

if __name__ == '__main__':
   app.run()
